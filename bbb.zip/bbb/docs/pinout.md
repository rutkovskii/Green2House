# BeagleBone Pinout

P9_01: GND

P9_03: 3.3V (optional)

P9_05: 5V (relays require 5V)



## I2C (OLED and DHT20)

P9_19: SCL

P9_20: SDA

## Relays 
P8_08: Pump Relay

P8_10: Heater Relay

P8_14: Water Pump Button to Relay