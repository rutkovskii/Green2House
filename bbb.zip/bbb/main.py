import time
import Adafruit_BBIO.ADC as ADC
import Adafruit_BBIO.GPIO as GPIO

from bbb_config import BBB_CONFIG as BC  # pins are here
from scripts.init_home import create_all
from scripts import utils
from scripts.send_data import send_samples

i2c, sensor, oled = create_all(BC.pins_dict)
ADC.setup()


#AIR: 3200
#DRY DIRT: 2900 - 3100
#MOIST DIRT: ~2900
#WET DIRT: 1500
#PURE WATER: 1450


# def measureValues():
#     #soil moisture
#     soilPercent, soil = utils.getSoilMoisture()
#     #DHT20 Temp/Hum
#     sensorF, sensorH = utils.getTempHum(sensor)[0], utils.getTempHum(sensor)[1]
#     values = [soil, sensorF, sensorH]
    
#     return values


def main():
    utils.relayOff(GPIO, BC.pins_dict.get('heater_relay_pin'))
    utils.relayOff(GPIO, BC.pins_dict.get('fan_relay_pin'))
    #utils.openGH()
    #time.sleep(1)
    #utils.closeGH()
    #utils.relayOff(GPIO, BC.pins_dict.get('h_bridge2'))
    #utils.relayOn(GPIO, BC.pins_dict.get('h_bridge2'))
    soilPercent, soil = utils.getSoilMoisture(BC.pins_dict.get('adc_pin')) #soilPercent is not used but still collected just in case
    sensorF, sensorH = utils.getTempHum(sensor) #measure initial values
    #print(GPIO.input("P9_15"))
    while True: 
        #print(GPIO.input(BC.pins_dict.get('button_pin')))
        if int(time.strftime('%S')) % 10 == 0: # measure value every x seconds
            #print(measureValues()[0])
            soilPercent, soil = utils.getSoilMoisture(BC.pins_dict.get('adc_pin'))
            sensorF, sensorH = utils.getTempHum(sensor)
            #measurements = measureValues()
            utils.dispOLED(oled=oled, temp=str(sensorF)[0:4], hum=str(sensorH)[0:4], moisture=soil, timestamp=time.strftime('%H:%M:%S'))
            utils.controlTempHum(sensorF, sensorH) #make appropriate environment changes based on temp and hum

            if BC.SEND_DATA:
                sample = utils.sense_sample(BC.user_id, sensorF, sensorH)
                samples = [sample]
                send_samples(url=SERVER_GET_DATA_URL, samples=samples)

            time.sleep(0.5) #sleep for at least 1 second to avoid multiple measurements in one second

        


if __name__ == "__main__":
    main()